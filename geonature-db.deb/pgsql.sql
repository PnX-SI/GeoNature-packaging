create table foo (
	id	int not null primary key,
	nom	varchar(32)
);
